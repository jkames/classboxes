public interface Car {
    void body();
    void engine();
    void tyres();
    void ac();
}
