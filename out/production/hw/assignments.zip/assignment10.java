abstract class wolswagan implements Car{
    public void tyres(){

    }
    public void ac(){}
    abstract void noac();
}

class Polo extends wolswagan{

    @Override
    public void body() {

    }

    @Override
    public void engine() {

    }

    @Override
    void noac() {

    }
}

class Wabc extends wolswagan{

    @Override
    public void body() {

    }

    @Override
    public void engine() {

    }

    @Override
    void noac() {

    }
}
public class assignment10 {

}
