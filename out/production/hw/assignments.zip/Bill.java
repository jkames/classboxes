public interface Bill {
    double calcBill(int units);
    void printBill(double amount);
}
