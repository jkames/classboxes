public class assignment5 {
    public static void main(String[] args) {
       String a = new String("1");
       String b = new String("212");
       String c = new String("32123");
       String d = new String("4321234");
       String e = new String("543212345");

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);
    }
}
