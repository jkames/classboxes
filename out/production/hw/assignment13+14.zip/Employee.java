public class Employee {
    private String name;
    private int id;
    private double salary;
    private int deptId;


    String getName(){return this.name;}
    void setName(String name){this.name=name;}

    int getId(){return this.id;}
    void setId(int id){this.id = id;}

    double getSalary(){return this.salary;}
    void setSalary(double salary){this.salary = salary;}

    int getDeptId(){return this.deptId;}
    void setDeptId(int deptId){this.deptId = deptId;}


}
